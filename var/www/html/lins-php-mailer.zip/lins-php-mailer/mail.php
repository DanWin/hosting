<pre>
<?php
require 'class/class.phpmailer.php';
$mail = new PHPMailer;
$mail->IsSMTP();								//Sets Mailer to send message using SMTP
$mail->Host = '';	//Sets the SMTP hosts of your Email hosting
$mail->Port = '25';								//Sets the default SMTP server port
$mail->SMTPAuth = true;							//Sets SMTP authentication. Utilizes the Username and Password variables
$mail->Username = 'Your Username';					//Sets SMTP username
$mail->Password = 'your password';					//Sets SMTP password
$mail->SMTPSecure = '';							//Sets connection prefix. Options are "", "ssl" or "tls"
$mail->From = 'your onion email';					//Sets the From email address for the message
$mail->FromName = "Your name";				    //Sets the From name of the message example username@abcdefghijklmnop1234567890.onion
$mail->AddAddress('Receiver Onion Email', 'receiver Name');		//Adds a "To" address
$mail->AddCC('', $_POST["name"]);	      //Adds a "Cc" address
$mail->WordWrap = 50;				                      //Sets word wrapping on the body of the message to a given number of characters
$mail->IsHTML(true);							//Sets message type to HTML				
$mail->Subject = "Your Subject ";				//Sets the Subject of the message
$mail->Body = "your text";				//An HTML or plain text message body
if($mail->Send())
{								//Send an Email. Return true on success or false on error
echo "Mail sent!";
}
else {
echo "Not Sent";
}
?>
</pre>
